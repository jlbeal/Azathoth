from pages.base_page import BasePage
from selenium.webdriver.common.by import By

class CartPage(BasePage):
    __add_to_cart = {'by':By.XPATH,'locator':'/html/body/div[2]/div/div/div[2]/div[1]/div/div[3]/button[1]/span'}
    __cart_total = {'by':By.ID, 'locator':'//*[@id="cart-total"]'}
    __view_cart = {'by':By.XPATH,'locator':'/html/body/header/div/div/div[3]/div/ul/li[2]/div/p/a[1]/strong'}
    __input_updated = {'by':By.XPATH,'locator':'/html/body/div[2]/div[2]/div/form/div/table/tbody/tr/td[4]/div/input'}
    __quantity_updated = {'by':By.XPATH,'locator':'/html/body/div[2]/div[2]/div/form/div/table/tbody/tr/td[4]/div/span/button[1]/i'}
    __checkout = {'by':By.XPATH,'locator':'=/html/body/div[2]/div[2]/div/div[3]/div[2]/a'}

    def __init__(self, driver) -> None:
        super().__init__(driver)
        self.add_to_cart()

    def add_to_cart(self):
        button_cart = self._get_element(self.add_to_cart['by'],self.add_to_cart['locator'])
        self._is_present(button_cart, 'No se encuentra el boton Add to Cart')
        self._is_visible(button_cart, 'El boton Add to Cart no se encuentra visible') 
        self._is_enabled(button_cart, 'El boton Add to Cart no se encuentra habilitado') 
        self._click(button_cart)

    def verificar_mensaje_success(self):
        mensaje_success = self._get_element(self.__message_success['by'],self.__message_success['locator'])
        self._is_present(mensaje_success,'No se encuentra el mensaje de success')
        self._is_visible(mensaje_success,'El mensaje de success no se encuentra visible')
       
    