from pages.base_page import BasePage
from selenium.webdriver.common.by import By

class MenuPage(BasePage):

    
    __button_search = {'by':By.CSS_SELECTOR, 'locator':'#search button'}
    __input_buscar = {'by':By.NAME,'locator':'search'}
    __img_logo = {'by':By.CSS_SELECTOR,'locator':'#logo img'}
    __desktops = {'by':By.XPATH, 'locator': '/html/body/div[1]/nav/div[2]/ul/li[1]/div/a' } #show all desktops 
    __laptopsnotebooks = {'by':By.XPATH, 'locator': '/html/body/div[1]/nav/div[2]/ul/li[2]/div/a'} #show all
    __components = {'by':By.XPATH, 'locator': '/html/body/div[1]/nav/div[2]/ul/li[3]/div/a'} #show all
    __tablets = {'by':By.XPATH, 'locator': '/html/body/div[1]/nav/div[2]/ul/li[4]/a'}
    __software = {'by':By.XPATH, 'locator':'/html/body/div[1]/nav/div[2]/ul/li[5]/a'}
    __phonespdas = {'by':By.XPATH, 'locator':'/html/body/div[1]/nav/div[2]/ul/li[6]/a'}
    __cameras = {'by':By.XPATH, 'locator': ':/html/body/div[1]/nav/div[2]/ul/li[7]/a'}
    __mp3players = {'by':By.XPATH, 'locator': '/html/body/div[1]/nav/div[2]/ul/li[8]/div/a'}


    def __init__(self, driver) -> None:
        super().__init__(driver)
        self.__verificar_menu()
        
    def __verificar_menu(self):
        img_element = self._get_element(self.__img_logo['by'],self.__img_logo['locator'])
        self._is_present(img_element,'No se encuentra la Imagen del Logo')
        self._is_visible(img_element,'El Logo no se encuentra visible')

    def click_boton_buscar(self):
        button_element = self._get_element(self.__button_search['by'], self.__button_search['locator'])
        self._is_present(button_element, 'No se encuentra el boton Buscar')
        self._is_visible(button_element, 'El boton buscar no se encuentra visible') 
        self._is_enabled(button_element, 'El boton de Busqueda no se encuentra habilitado') 
        self._click(button_element)

    def ingresar_busqueda(self,text):
        input_element = self._get_element(self.__input_buscar['by'],self.__input_buscar['locator'])
        self._is_present(input_element,'No se encuentra el input de Busqueda')
        self._is_visible(input_element,'El input de Busqueda no se encuentra visible')
        self._write(input_element,text)

    def buscar_producto(self,text):
        self.ingresar_busqueda(text)
        self.click_boton_buscar()

    def back_landingpage(self,url):
        self._driver.get(url)

    def logo_landingpage(self):
        logo_element = self._get_element(self.__img_logo['by'],self.__img_logo['locator'])
        self._click(logo_element)

    #modulos tabs
    def mod_desktops(self):
        button_desktops = self._get_element(self.__desktops['by'],self.__desktops['locator'])
        self._click(button_desktops)

    def mod_laptops(self):    
        button_laptopsnotebooks = self._get_element(self.__laptopsnotebooks['by'],self.__laptopsnotebooks['locator'])
        self._click(button_laptopsnotebooks)

    def mod_components(self):
        button__components = self._get_element(self.__components['by'],self.__components['locator'])
        self._click(button__components)

    def mod_tablets(self):    
        button__tablets = self._get_element(self.__tablets['by'],self.__tablets['locator'])
        self._click(button__tablets)

    def mod_software(self):
        button__software = self._get_element(self.__software['by'],self.__software['locator'])
        self._click(button__software)

    def mod_phones(self):
        button__phonespdas = self._get_element(self.__phonespdas['by'],self.__phonespdas['locator'])
        self._click(button__phonespdas)

    def mod_cameras(self):
        button__cameras = self._get_element(self.__cameras['by'],self.__cameras['locator'])
        self._click(button__cameras)

    def mod_mp3players(self):
        button__mp3players = self._get_element(self.__mp3players['by'],self.__mp3players['locator'])
        self._click(button__mp3players)